#!/bin/bash

export RESULT_PATH=`pwd`/results
sed -i 's@.*regs.dat.*@;i=0;fd=$fopen("./regs.dat","r");@' cpu.v
sed -i 's@.*dmem.dat.*@;i=0;fd=$fopen("./dmem.dat","r");@' cpu.v
sed -i 's@.*imem.dat.*@;i=0;fd=$fopen("./imem.dat","r");@' cpu.v
sed -i 's@.*regs_result.dat.*@;i=0;fd=$fopen("./regs_result.dat","w");@' cpu.v
sed -i 's@.*mem_result.dat.*@;i=0;fd=$fopen("./mem_result.dat","w");@' cpu.v
line_num=`grep -n "end" cpu.v | tac | grep -m 2 "end" | tail -1f | awk -F':' '{print $1}'`
sed -i ''"${line_num}"'s/.*/;$display("PC is %d",PC);  end/' cpu.v 

score_0=0
score_1=0
score_2=0

#Grade for problem 0
echo "== Problem 0 =="
for testcase in A B C D
do
cp $RESULT_PATH/0/${testcase}/* .
mv regs_result.dat  regs_result_correct.dat
cp max_pc.txt max_pc_correct.dat
rm PC_count.txt
rm max_pc.txt
./run.sh | grep "PC is"  > PC_count.txt
./find_max.awk PC_count.txt > max_pc.txt
incorrect=`diff regs_result.dat regs_result_correct.dat | wc -l`
max_pc_correct=`cat "max_pc_correct.dat"`
max_pc=`cat "max_pc.txt"`
difference=`echo "${max_pc} - ${max_pc_correct}" | bc `  
echo "Incorrect is $incorrect for testcase $testcase"
echo "Difference is $difference for testcase $testcase"
if [ $incorrect -eq 0 ]; then
 score_0=`echo "${score_0}+5" | bc`
    if [ $difference -gt 4 ];then
        score_0=`echo "${score_0}-0.5" | bc`
    fi
fi
done

echo "score_0 is ${score_0}"

###Grade for problem 2
echo "== Problem 1 =="
for testcase in  A B C D E F G 
do
cp $RESULT_PATH/1/${testcase}/* .
mv regs_result.dat  regs_result_correct.dat
cp max_pc.txt max_pc_correct.dat
rm PC_count.txt
rm max_pc.txt
./run.sh | grep "PC is" > PC_count.txt
./find_max.awk PC_count.txt > max_pc.txt
incorrect=`diff regs_result.dat regs_result_correct.dat | wc -l`
max_pc_correct=`cat "max_pc_correct.dat"`
max_pc=`cat "max_pc.txt"`
difference=$((${max_pc} - ${max_pc_correct})) 
echo "Incorrect is $incorrect for testcase $testcase"
echo "Difference is $difference for testcase $testcase"
if [ $incorrect -eq 0 ]; then
 if [ $testcase == "A" ]; then 
    score_1=20 
 else 
    score_1=`echo "${score_1}+4" | bc`
    if [[ $difference -gt 4 || $difference -lt -4 ]];then
        score_1=`echo "${score_1}-1" | bc`
    fi
 fi 
fi
done

if [ ${score_1} -lt 40 ]; then
  echo "score_1 is ${score_1}"
else
  echo "score_1 is 40"
fi
#
##
###Grade for problem 3 
echo "== Problem 2 =="
count=0;
for testcase in   I A B C D E F G H
do
cp $RESULT_PATH/2/${testcase}/* .
mv regs_result.dat  regs_result_correct.dat
cp max_pc.txt max_pc_correct.dat
rm PC_count.txt
rm max_pc.txt
./run.sh | grep "PC is" > PC_count.txt
./find_max.awk PC_count.txt > max_pc.txt
max_pc_correct=`cat "max_pc_correct.dat"`
max_pc=`cat "max_pc.txt"`
difference=$((${max_pc} - ${max_pc_correct}))
#echo "max_pc is $max_pc for testcase $testcase"
#echo "max_pc_correct is $max_pc_correct for testcase $testcase"
incorrect=`diff regs_result.dat regs_result_correct.dat | wc -l`
echo "Incorrect is $incorrect for testcase $testcase"
echo "Difference is $difference for testcase $testcase"
if [ $incorrect -eq 0 ]; then
 if [ $testcase == "I" ];then
    score_2=20 
 else
    score_2=`echo "${score_2}+3" | bc`
    if [[ $difference -gt 4 || $difference -lt -4 ]]; then
	count=`echo "${count}+1" | bc`
        score_2=`echo "${score_2}-1" | bc`
	#echo "score is: $score_2"
    fi
 fi
fi
done
#
if [ ${score_2} -lt 40 ]; then
  echo "score_2 is ${score_2}"
else
  echo "score_2 is 40"
fi

##
