VIVADO_PATH=/soft/xilinx-vivado-hl-webpack/Vivado/2016.4/bin
$VIVADO_PATH/xvlog --relax tb_cpu.v cpu.v
$VIVADO_PATH/xelab -debug typical tb_cpu_p1 -s top_sim
$VIVADO_PATH/xsim -R top_sim
