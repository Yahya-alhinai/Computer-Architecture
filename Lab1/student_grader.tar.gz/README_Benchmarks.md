Problem 0 : 
A. A single OR instruction
B. A single AND instruction 
C. A single SLT instruction
D. A single SLLV instruction 

0.A.1
or $r1, $r2, $r3  
0.B.1 
and $r1, $r2, $r3
0.C.1
slt $r1, $r2, $r3
0.D.1
sllv $r1, $r2, $r3


Problem 1 : 
A. cmov only
B. add followed by cmov 
C. LW followed by cmov 
D. add followed by nop,cmov 
E. LW followed by nop,cmov
F. cmov followed by 2 nops and add 
G. cmov followed by 2 nops and lw 

1.A.0
cmov  $r1,$r2,$r3,$r4 
1.B.0
add $r1,$r4,$r5
cmov  $r1,$r2,$r3,$r4 
1.C.0
lw $r1, 0($r4)
cmov  $r1,$r2,$r3,$r4 
1.D.0
add $r1,$r4,$r5
nop
cmov  $r1,$r2,$r3,$r4 
1.E.0
lw $r1, 0($r4)
nop
cmov  $r1,$r2,$r3,$r4 
1.F.0
add $r1,$r4,$r5
nop
nop
cmov  $r1,$r2,$r3,$r4 
1.G.0
lw $r1, 0($r4)
nop
nop
cmov  $r1,$r2,$r3,$r4 

Problem 2 :
A. add followed by bpdcr 
B. LW followed by bpdcr
C. add followed by nop, bpdcr 
D. add followed by nop, nop, bpdcr
E. LW followed by nop, bpdcr 
F. LW followed by nop, nop, bpdcr
G. Hazard
H. Hazard
I. A single bpdcr

2.A.0
add $r4,$r2,$r5
bpdcr $r4,-2
2.B.0
lw $r2, 0($r4)
bpdcr $r2,-2
2.C.0
add $r4,$r2,$r5
nop
bpdcr $r4,-3
2.D.0
add $r4,$r2,$r5
nop
nop
bpdcr $r4,-4
2.E.0
lw $r2, 0($r4)
nop
bpdcr $r2,-3
2.F.0
lw $r2, 0($r4)
nop
nop
bpdcr $r2,-4
2.G.0
bpdcr $r2, 0   //RAW hazard caused due to bpdcr write
add $r3, $r2, $r4
2.H.0
bpdcr $r2, 0   //RAW hazard caused due to bpdcr write 
lw $r3, 4($r2)
2.I.0
bpdcr $r4,2
