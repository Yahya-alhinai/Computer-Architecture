Copy the cpu.v file to this folder and run ./grade.sh to evaluate your implementation on the given benchmarks. The benchmarks are described in README_Benchmarks.md
