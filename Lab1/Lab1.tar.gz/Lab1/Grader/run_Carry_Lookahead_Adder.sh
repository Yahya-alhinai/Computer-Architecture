VIVADO_PATH=/soft/xilinx-vivado-hl-webpack/Vivado/2016.4/bin
rm -rf temp
mkdir temp
cp *.v temp
cd temp

$VIVADO_PATH/xvlog Carry_Block_1.v Carry_Block_2.v Carry_Block_3.v Carry_Block_4.v Carry_Block_5.v Carry_Block_6.v  Carry_Block_7.v  Carry_Block_8.v Carry_Block_9.v Carry_Block_10.v PG_Block.v Carry_Lookahead_Adder.v one_bit_ALU.v tb_Carry_Lookahead_Adder.v
$VIVADO_PATH/xelab -debug typical tb_Carry_Lookahead_Adder -s top_sim
$VIVADO_PATH/xsim -R top_sim
