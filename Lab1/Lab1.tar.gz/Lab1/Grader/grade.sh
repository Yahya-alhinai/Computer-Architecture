#!/bin/bash

CUR_PATH=`pwd`
i1=`./run_one_bit_ALU.sh | grep "The total incorrect count is" | awk '{print $6}'`
i2=`./run_ripple_carry_adder.sh  | grep "The total incorrect count is" | awk '{print $6}'`
i3=`./run_Carry_Lookahead_Adder.sh  | grep "The total incorrect count is" | awk '{print $6}'`

s1=`echo "scale=2;10 * ((12-$i1)/12.00)" | bc`
s2=`echo "scale=2;40 * ((2097152-$i2)/2097152)" | bc`
s3=`echo "scale=2;50 * ((2097152-$i3)/2097152)" | bc`

echo "Incorrect test cases for problem 1 is $i1"
echo "Incorrect test cases for problem 2 is $i2"
echo "Incorrect test cases for problem 3 is $i3"

echo "The final score is for problem 1 is $s1"
echo "The final score is for problem 2 is $s2"
echo "The final score is for problem 3 is $s3"
