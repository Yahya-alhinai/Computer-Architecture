VIVADO_PATH=/soft/xilinx-vivado-hl-webpack/Vivado/2016.4/bin
rm -rf temp
mkdir temp
cp *.v temp
cd temp
$VIVADO_PATH/xvlog one_bit_ALU.v tb_one_bit_ALU.v
$VIVADO_PATH/xelab -debug typical tb_one_bit_ALU -s top_sim
$VIVADO_PATH/xsim -R top_sim
