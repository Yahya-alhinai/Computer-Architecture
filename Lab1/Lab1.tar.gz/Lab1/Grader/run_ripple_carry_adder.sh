VIVADO_PATH=/soft/xilinx-vivado-hl-webpack/Vivado/2016.4/bin
rm -rf temp
mkdir temp
cp *.v temp
cd temp
$VIVADO_PATH/xvlog one_bit_ALU.v ripple_carry_ten_bit.v tb_ripple_carry_10_bit.v 
$VIVADO_PATH/xelab -debug typical tb_ripple_carry_10_bit -s top_sim
$VIVADO_PATH/xsim -R top_sim
