Benchmark 1 :
The first benchmark tests 'lw' instruction.
lw r5, 0(r1)

Benchmark 2 :
The second benchmark tests 'sw' instruction.
sw r3, 0(r0)

Benchmark 3 :
The third benchmark tests 'add' instruction.
add $r1, $r4, r5 

Benchmark 4 :
The fourth benchmark tests a sequence of add instructions with a
RAW (read-after-write) hazard and load, which is solved using forwarding
and a stall.

lw $r3, 0($r0)
lw $r4, 1($r0)
add $r5, $r3, $r4
add $r6, $r5, $r4

Benchmark 5 :
Tests forwarding between WB stage and ID stage for ALU operation.
add $r1, $r2, $r3
nop
nop
add $r5,$r1, $r2

Benchmark 6 :
Tests the BNE instruction by incrementing a register until it reaches a particular value.

add $r2, $r1, $r2
nop
nop
nop
bne $r2, $r6, -5

Benchmark 7 : 
Tests hazard on SW rt register. 
add $r3, $r1, $r4 
sw $r3, 0($r0)

Benchmark 8 : 
Tests hazard on SW rt register caused by a LW to that register.
lw $r3, 0($r0) 
sw $r3, 4($r0)

Benchmark 9 :
Tests the SLLV operation
sllv $43, $r1, $r2
