# CSCI-4203-Fall-2019-Lab3
This code models a direct mapped cache shown in fig 5.12.3 in the appendix.
Use the runscript to run the cache with several testcases. 
The following testcases are provided : 

1. Compulsory miss on read.
2. Compulsory miss on write.
3. Read hit on a clean cache line.
4. Write hit on a clean cache line.
5. Write hit on a dirty cache line. 
6. Write conflict miss on a dirty cache line.
7. Read hit on a dirty cache line.
8. Read conflict miss on a dirty cache line.
9. Read conflict miss on a clean cache line.
10. Write conflict miss on a clean cache line.


