#!/bin/bash

VIVADO_PATH=/soft/xilinx-vivado-hl-webpack/Vivado/2016.4/bin
$VIVADO_PATH/xvlog --sv package_definitions.sv dm_cache_data.sv dm_cache_fsm.sv testbench.sv
$VIVADO_PATH/xelab -debug typical test_main -s top_sim
$VIVADO_PATH/xsim -R top_sim
