Copy your *.sv files into this folder (except testbench.sv)
Run the command  ./grade_scores.sh LRU 
to get the result for LRU. 
Similarly, use LFU or MRU to get the results for
those replacement policies. 

