#!/bin/bash

net_score=0
extra_points=0
for replacement_scheme in $1 #LFU #LRU MFU
do
   score=0
   echo "Grading ${replacement_scheme}"
   for associativity in 1 2 3 4 5 6 7 8  
   do
     echo "... Grading associativity ${associativity} ... "
     #cp ./backup_${replacement_scheme}/*.sv .
     #cp backup_testbench/testbench.sv .
     sed -i 's/.*parameter.*N.*=.*/parameter int N='"${associativity}"';/' package_definitions.sv
     timeout 50 ./run.sh > log1
     if [ $? -eq 0 ]; then
        score=$(($score + 2))
        echo "Code can finish execution on time for associativity ${associativity} for replacement policy ${replacement_scheme}  -- +2"
     fi

     #### Check whether Nth line got a read-hit for N-way associative
     sum=$((11111110 + ${associativity} - 1))
     line=`cat log1 | grep -m1 -n "8925650367593487 get data=${sum}" | awk -F":" '{print $1}'`
     #echo ${sum}
     #echo ${line}
     if [ "$line" != ""  ];then 
       get_time=`cat log1 | grep -m1 "8925650367593487 get data=${sum}" | awk -F"ns:" '{print $1}'`
       #read addr
       read_time=`cat log1 | head -n ${line} | tac | grep -m 1 "2352986204367570" | awk -F"ns:" '{print $1}'` #Get the read time
       difference=`echo "scale=0; (${get_time}-${read_time})/1" | bc`
       #echo "The difference is $difference"
       if [ "$difference" != "" ];then
          if [ $difference -lt 10 ];then
            score=`echo "${score}+2" | bc`
            echo "Hit on line ${associativity} -- +2"
          else
            echo "Miss on line ${associativity} -- +0"
          fi
       fi
     else
       echo "CPU got incorrect data on read, should have got ${sum} for ${associativity} line, check log --  +0 "
     fi

     #Check the correct eviction order
     #Memory
     cat log1 | grep  "345342650274567" | grep Write | awk '{print $NF}'  > log
     incorrect=`diff log log_${replacement_scheme}_${associativity} | wc -l `
     if [ ${incorrect} -le 1 ] ; 
     then
        echo "Correct eviction order for associativity ${associativity} -- +10"
        score=`echo "${score}+10" | bc `
     else
        echo "Incorrect eviction order for associativity ${associativity}, check log_${replacement_scheme}_${associativity} -- +0"
     fi
   
   done
   if [ $replacement_scheme == LFU ] ;then
       max=40 
   elif [ $replacement_scheme == LRU ]; then
       max=50 
   else 
       max=10
   fi
   if [ $score -gt $max ];then
       score=$max
   fi 
   echo " Score for ${replacement_scheme} is $score   "
   net_score=$(($net_score + $score))
done
echo " Total score is $net_score "
echo " Total score is $net_score " >> ../scores.txt
